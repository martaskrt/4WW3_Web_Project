Name: Marta Skreta
Student number: 001416801
Course: CS 4WW3

Completed Add-on task #1 for bonus

Cs 4WW3 Assignment 1
Due: Feb. 7, 2017